import sys
sys.dont_write_bytecode = True